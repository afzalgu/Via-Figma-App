

let emailid = document.querySelector("#Email");
let passwordid = document.querySelector("#password");
let btn = document.querySelector("#submitbtn");


 function validationemail (email){
    let regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/gm;
    return regex.test(email);
    
    
     
}

function validationpassword(password){
    let regex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    return regex.test(password);
     
}

btn.addEventListener("click" , function(){
    let email = emailid.value;
    let password = passwordid.value;
   

    if(validationemail(email) && validationpassword(password)){
        btn.disabled = false;
       
        // return true;
        setTimeout(function() {
            window.location.href = "index2.html";
        }, 1000); 

        alert("successful login");

        
    }

    else{
        alert("Invalid Email and Password  Format check please");
        return false;
    }


})

   function  myfunction(){
    
var a = document.querySelector("#password");
  if(a.type === "password"){
      a.type = "text";

  }
  else{
    a.type ="password";
  }

   }




//  THE NEXT PAGE CODING START NOW 



  let btn1 = document.querySelector("#btntask");
  let conter = document.querySelector(".conatainer");
  let text = document.querySelector(".taskbox");
  let adding = document.querySelector(".add");
  let secondcont = document.querySelector(".conatainer");


        
 

        function show(e) {

           
          
            var container = document.querySelector('.conatainer');
            var taskbox = document.querySelector('.taskbox');
            var textform = document.getElementById('textform');
        
            if (container.style.display === "none") {
                container.style.display = "block";
                taskbox.style.display = "block";
                textform.textContent = "- Hide task";

                
               
            } else {
                container.style.display = "none";
                taskbox.style.display = "none";
                textform.textContent = "+ Add new task";
              
            }
            e.preventDefault();
          
        }
      
        

            // Started the third page function of Location
            let btn2 = document.querySelector("#btnlocation");
            function mybtn2(){
                var c = setTimeout(() => {
                    window.location.href = "index3.html";
                }, 10);
            }

           


        //  let canceled = document.querySelector(".cancel");

        // //  canceled.addEventListener("click",function(){
        // //       window.location.href = "index3.html";
        // //  })

        //  function canceled(){

        //     if(canceled == "text"){
        //        var d = setTimeout(() => {
        //              window.location.href = "index.html";
        //        }, 1000);
        //     }
        //  }